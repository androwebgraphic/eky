import passport from 'passport';
// ...existing code...

export default passport;
